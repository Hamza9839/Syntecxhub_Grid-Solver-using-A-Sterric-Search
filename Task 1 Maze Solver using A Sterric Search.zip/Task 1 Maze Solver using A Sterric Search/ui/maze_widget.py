"""Custom Qt widget for displaying a Maze and completed A* search."""

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QWidget


class MazeWidget(QWidget):
    """Draw a maze grid using the data from a Maze and SearchResult."""

    COLORS = {
        "wall": QColor("#263238"),
        "open": QColor("#f5f7fa"),
        "explored": QColor("#b9d7ea"),
        "path": QColor("#ffd166"),
        "start": QColor("#38a169"),
        "goal": QColor("#e05260"),
        "grid": QColor("#90a4ae"),
        "text": QColor("#17202a"),
        "frontier": QColor("#c4b5fd"),
        "current": QColor("#f97316"),
    }
    cell_clicked = Signal(tuple)

    def __init__(self, maze, parent=None):
        super().__init__(parent)
        self.maze = maze
        self.search_result = None
        self.search_snapshot = None
        self.current_node = None
        self.frontier = set()
        self.edit_mode = False
        self.setMinimumSize(500, 500)
        self.setAccessibleName("Maze grid")

    def set_maze(self, maze):
        """Display a new Maze and clear any previous search state."""
        self.maze = maze
        self.search_result = None
        self.search_snapshot = None
        self.current_node = None
        self.frontier = set()
        self.update()

    def set_search_result(self, result):
        """Display the existing A* SearchResult without running a search."""
        self.search_result = result
        self.search_snapshot = None
        self.current_node = None
        self.frontier = set()
        self.update()

    def set_search_snapshot(self, snapshot):
        """Display one incremental A* snapshot without requiring a final result."""
        self.search_result = snapshot
        self.search_snapshot = snapshot
        self.current_node = snapshot.current
        self.frontier = set(snapshot.frontier)
        self.update()

    def set_edit_mode(self, enabled):
        self.edit_mode = enabled
        self.setCursor(
            Qt.CursorShape.PointingHandCursor
            if enabled
            else Qt.CursorShape.ArrowCursor
        )

    def _position_at(self, point):
        cell_size, left, top = self._cell_geometry()
        if not cell_size:
            return None
        column = int((point.x() - left) / cell_size)
        row = int((point.y() - top) / cell_size)
        if 0 <= row < len(self.maze.grid) and 0 <= column < len(self.maze.grid[0]):
            return row, column
        return None

    def mousePressEvent(self, event):
        if self.edit_mode and event.button() in (
            Qt.MouseButton.LeftButton,
            Qt.MouseButton.RightButton,
        ):
            position = self._position_at(event.position())
            if position is not None:
                self.cell_clicked.emit(position)
                event.accept()
                return
        super().mousePressEvent(event)

    def _cell_geometry(self):
        row_count = len(self.maze.grid)
        column_count = len(self.maze.grid[0]) if row_count else 0
        if not row_count or not column_count:
            return 0, 0, 0

        cell_size = min(
            self.width() / column_count,
            self.height() / row_count,
        )
        grid_width = cell_size * column_count
        grid_height = cell_size * row_count
        left = (self.width() - grid_width) / 2
        top = (self.height() - grid_height) / 2
        return cell_size, left, top

    def _cell_color(self, position):
        cell = self.maze.grid[position[0]][position[1]]
        result = self.search_result
        if cell == self.maze.WALL:
            return self.COLORS["wall"]
        if position == self.maze.start:
            return self.COLORS["start"]
        if position == self.maze.goal:
            return self.COLORS["goal"]
        if position == self.current_node:
            return self.COLORS["current"]
        if result is not None and hasattr(result, "path") and result.path is not None:
            if position in result.path:
                return self.COLORS["path"]
        if position in self.frontier:
            return self.COLORS["frontier"]
        if result is not None and position in result.closed_set:
            return self.COLORS["explored"]
        return self.COLORS["open"]

    def _cell_label(self, position):
        cell = self.maze.grid[position[0]][position[1]]
        if cell == self.maze.WALL:
            return "#"
        if position == self.maze.start:
            return "S"
        if position == self.maze.goal:
            return "G"
        if position == self.current_node:
            return "C"
        if self.search_result is not None:
            if hasattr(self.search_result, "path") and (
                self.search_result.path is not None
                and position in self.search_result.path
            ):
                return "P"
            if position in self.search_result.closed_set:
                return "E"
        if position in self.frontier:
            return "F"
        return "."

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor("#ffffff"))

        cell_size, left, top = self._cell_geometry()
        if not cell_size:
            return

        row_count = len(self.maze.grid)
        column_count = len(self.maze.grid[0])
        for row_index in range(row_count):
            for column_index in range(column_count):
                position = (row_index, column_index)
                rectangle = QRectF(
                    left + column_index * cell_size,
                    top + row_index * cell_size,
                    cell_size,
                    cell_size,
                )
                painter.fillRect(rectangle, self._cell_color(position))
                painter.setPen(QPen(self.COLORS["grid"], 1))
                painter.drawRect(rectangle)

                label = self._cell_label(position)
                if label != ".":
                    painter.setPen(self.COLORS["text"])
                    font = painter.font()
                    font.setBold(True)
                    font.setPointSize(max(10, int(cell_size * 0.28)))
                    painter.setFont(font)
                    painter.drawText(
                        rectangle,
                        Qt.AlignmentFlag.AlignCenter,
                        label,
                    )
