"""Main window for the A* Maze Solver desktop application."""

import sys
import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QApplication,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QFrame,
    QGridLayout,
    QGroupBox,
    QSlider,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from astar import AStarStepper, astar_search
from maze import Maze
from .maze_widget import MazeWidget


class MainWindow(QMainWindow):
    """Coordinate the maze widget, search controls, and result information."""

    LAST_VERIFIED_TEST_COUNT = 75

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("A* Maze Solver")
        self.setMinimumSize(1000, 650)
        self.maze = Maze()
        self.search_result = None
        self.stepper = None
        self.animation_started_at = None
        self.edit_mode = False
        self.placement_mode = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._advance_animation)
        self._build_ui()
        self._reset_view()

    def _build_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        root_layout = QVBoxLayout(central_widget)
        root_layout.setContentsMargins(20, 20, 20, 20)
        root_layout.setSpacing(14)

        header = QLabel("A* Maze Solver")
        header.setObjectName("header")
        root_layout.addWidget(header)

        content_layout = QHBoxLayout()
        content_layout.setSpacing(20)
        root_layout.addLayout(content_layout, 1)

        self.maze_widget = MazeWidget(self.maze)
        self.maze_widget.cell_clicked.connect(self._handle_cell_click)
        content_layout.addWidget(self.maze_widget, 1)
        content_layout.addWidget(self._create_info_panel())

        controls = QHBoxLayout()
        controls.addStretch()
        self.solve_button = QPushButton("Start / Solve")
        self.pause_button = QPushButton("Pause")
        self.edit_button = QPushButton("Edit Maze")
        self.clear_button = QPushButton("Clear Maze")
        self.reset_button = QPushButton("Reset")
        self.load_button = QPushButton("Load Sample Maze")
        self.solve_button.clicked.connect(self.start_or_resume)
        self.pause_button.clicked.connect(self.pause_animation)
        self.edit_button.clicked.connect(self.toggle_edit_mode)
        self.clear_button.clicked.connect(self.clear_maze)
        self.reset_button.clicked.connect(self.reset_maze)
        self.load_button.clicked.connect(self.load_sample_maze)
        controls.addWidget(self.solve_button)
        controls.addWidget(self.pause_button)
        controls.addWidget(self.edit_button)
        controls.addWidget(self.clear_button)
        controls.addWidget(self.reset_button)
        controls.addWidget(self.load_button)
        root_layout.addLayout(controls)

        speed_layout = QHBoxLayout()
        speed_label = QLabel("Speed Controller:")
        speed_label.setObjectName("speedControllerLabel")
        speed_layout.addWidget(speed_label)
        self.speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.speed_slider.setAccessibleName("Speed Controller")
        self.speed_slider.setToolTip("Control the A* animation speed")
        self.speed_slider.setRange(100, 1000)
        self.speed_slider.setValue(350)
        self.speed_slider.setInvertedAppearance(True)
        self.speed_slider.valueChanged.connect(self._update_timer_interval)
        speed_layout.addWidget(self.speed_slider)
        root_layout.addLayout(speed_layout)

        self.setStyleSheet(
            """
            QMainWindow { background: #eef2f6; }
            QLabel#header {
                color: #17202a;
                font-size: 26px;
                font-weight: 700;
            }
            QLabel#panelTitle {
                color: #17202a;
                font-size: 18px;
                font-weight: 700;
            }
            QFrame#infoPanel {
                background: #ffffff;
                border: 1px solid #d6dde3;
                border-radius: 8px;
            }
            QScrollArea#sidebarScroll {
                background: #ffffff;
                border: 1px solid #d6dde3;
                border-radius: 8px;
            }
            QFrame#infoPanel QLabel {
                color: #17202a;
                background: transparent;
                font-size: 12px;
            }
            QFrame#infoPanel QLabel#panelTitle {
                color: #17202a;
                font-size: 18px;
                font-weight: 700;
            }
            QFrame#infoPanel QGroupBox {
                color: #17202a;
                background: #f8fafc;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                margin-top: 10px;
                padding: 12px 8px 8px 8px;
                font-weight: 700;
            }
            QFrame#infoPanel QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 4px;
                color: #17202a;
                background: #f8fafc;
            }
            QPushButton {
                padding: 9px 16px;
                border: 1px solid #b0bec5;
                border-radius: 5px;
                background: #2563eb;
                color: #ffffff;
                font-weight: 600;
            }
            QPushButton:hover { background: #1d4ed8; }
            QPushButton:pressed { background: #1e40af; }
            QPushButton:disabled { background: #cbd5e1; color: #64748b; }
            """
        )

    def _create_info_panel(self):
        scroll_area = QScrollArea()
        scroll_area.setObjectName("sidebarScroll")
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        scroll_area.setMinimumWidth(340)
        panel = QFrame()
        panel.setObjectName("infoPanel")
        panel.setMinimumWidth(310)
        scroll_area.setWidget(panel)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        title = QLabel("A* MAZE SOLVER")
        title.setObjectName("panelTitle")
        layout.addWidget(title)

        maze_card = QGroupBox("Maze Information")
        maze_grid = QGridLayout(maze_card)
        self.maze_status_label = QLabel()
        self.grid_size_label = QLabel()
        self.total_cells_label = QLabel()
        self.wall_cells_label = QLabel()
        self.open_cells_label = QLabel()
        for row, (name, value) in enumerate((
            ("Maze Status:", self.maze_status_label),
            ("Grid Size:", self.grid_size_label),
            ("Total Cells:", self.total_cells_label),
            ("Walls:", self.wall_cells_label),
            ("Open Cells:", self.open_cells_label),
        )):
            self._add_info_row(maze_grid, row, name, value)
        layout.addWidget(maze_card)

        size_card = QGroupBox("Change Grid Size")
        size_layout = QGridLayout(size_card)
        size_layout.addWidget(QLabel("Rows:"), 0, 0)
        self.rows_spinbox = QSpinBox()
        self.rows_spinbox.setRange(2, 50)
        self.rows_spinbox.setValue(len(self.maze.grid))
        self.rows_spinbox.setToolTip("Number of maze rows")
        size_layout.addWidget(self.rows_spinbox, 0, 1)
        size_layout.addWidget(QLabel("Columns:"), 1, 0)
        self.columns_spinbox = QSpinBox()
        self.columns_spinbox.setRange(2, 50)
        self.columns_spinbox.setValue(
            len(self.maze.grid[0]) if self.maze.grid else 2
        )
        self.columns_spinbox.setToolTip("Number of maze columns")
        size_layout.addWidget(self.columns_spinbox, 1, 1)
        self.apply_size_button = QPushButton("Apply Grid Size")
        self.apply_size_button.clicked.connect(self.apply_grid_size)
        size_layout.addWidget(self.apply_size_button, 2, 0, 1, 2)
        layout.addWidget(size_card)

        result_card = QGroupBox("A* Result")
        result_grid = QGridLayout(result_card)
        self.algorithm_label = QLabel()
        self.heuristic_label = QLabel()
        self.start_label = QLabel()
        self.goal_label = QLabel()
        self.mode_label = QLabel()
        self.status_label = QLabel()
        self.shortest_distance_label = QLabel()
        self.path_cost_label = QLabel()
        self.path_length_label = QLabel()
        self.explored_label = QLabel()
        self.frontier_label = QLabel()
        self.execution_label = QLabel()
        self.current_node_label = QLabel()
        self.current_g_label = QLabel()
        self.current_h_label = QLabel()
        self.current_f_label = QLabel()
        self.path_label = QLabel()
        self.path_label.setWordWrap(True)
        result_rows = (
            ("Algorithm:", self.algorithm_label),
            ("Heuristic:", self.heuristic_label),
            ("Start:", self.start_label),
            ("Goal:", self.goal_label),
            ("Mode:", self.mode_label),
            ("Status:", self.status_label),
            ("Shortest Distance:", self.shortest_distance_label),
            ("Path Length:", self.path_length_label),
            ("Explored Cells:", self.explored_label),
            ("Frontier:", self.frontier_label),
            ("Execution Time:", self.execution_label),
            ("Current Node:", self.current_node_label),
            ("Current g(n):", self.current_g_label),
            ("Current h(n):", self.current_h_label),
            ("Current f(n):", self.current_f_label),
            ("Shortest Path:", self.path_label),
        )
        for row, (name, value) in enumerate(result_rows):
            self._add_info_row(result_grid, row, name, value)
        layout.addWidget(result_card)
        test_card = QGroupBox("Test Status")
        test_grid = QGridLayout(test_card)
        self.test_status_label = QLabel()
        self.tests_passed_label = QLabel()
        self.test_command_label = QLabel()
        self._add_info_row(test_grid, 0, "Status:", self.test_status_label)
        self._add_info_row(
            test_grid, 1, "Tests Passed:", self.tests_passed_label
        )
        self._add_info_row(
            test_grid, 2, "Command:", self.test_command_label
        )
        layout.addWidget(test_card)
        layout.addWidget(QLabel("Legend"))
        layout.addWidget(QLabel("S Start   G Goal   # Wall   . Open"))
        layout.addWidget(QLabel("C Current   F Frontier   E Explored"))
        layout.addWidget(QLabel("P Final Path"))
        layout.addStretch()
        return scroll_area

    @staticmethod
    def _add_info_row(grid, row, name, value):
        label = QLabel(name)
        label.setStyleSheet("font-weight: 600;")
        value.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        grid.addWidget(label, row, 0)
        grid.addWidget(value, row, 1)

    def update_maze_information(self):
        """Refresh sidebar values derived from the current Maze."""
        rows = len(self.maze.grid)
        columns = len(self.maze.grid[0]) if rows else 0
        total = sum(len(row) for row in self.maze.grid)
        walls = sum(
            cell == self.maze.WALL for row in self.maze.grid for cell in row
        )
        self.maze_status_label.setText(
            "Valid" if self.maze.validate() else "Invalid Maze"
        )
        self.grid_size_label.setText(f"{rows} x {columns}" if rows else "N/A")
        self.total_cells_label.setText(str(total))
        self.wall_cells_label.setText(str(walls))
        self.open_cells_label.setText(str(total - walls))
        self.start_label.setText(f"Start: {self.maze.start}")
        self.goal_label.setText(f"Goal: {self.maze.goal}")

    def update_test_information(self):
        """Show the latest verified project test-suite result."""
        self.test_status_label.setText("All Passed")
        self.tests_passed_label.setText(
            f"{self.LAST_VERIFIED_TEST_COUNT} passed"
        )
        self.test_command_label.setText("pytest -q")

    def update_search_information(self, result=None):
        """Refresh sidebar values from a final result or live step snapshot."""
        if result is None:
            self.status_label.setText("Status: Ready")
            self.heuristic_label.setText("Manhattan distance")
            self.path_label.setText("Shortest Path: -")
            self.shortest_distance_label.setText("Shortest Distance: -")
            self.path_cost_label.setText("Path Cost: -")
            self.path_length_label.setText("Path Length: -")
            self.explored_label.setText("Explored Cells: -")
            self.frontier_label.setText("Frontier Cells: -")
            self.execution_label.setText("Execution Time: -")
            return
        self.explored_label.setText(
            f"Explored Cells: {len(result.closed_set)}"
        )
        if hasattr(result, "frontier"):
            self.status_label.setText("Status: Searching...")
            self.frontier_label.setText(
                f"Frontier Cells: {len(result.frontier)}"
            )
            self.current_node_label.setText(f"Current Node: {result.current}")
            self.current_g_label.setText(
                f"Current g: {result.g_score[result.current]}"
            )
            self.current_h_label.setText(f"Current h: {result.h_score}")
            self.current_f_label.setText(
                f"Current f: {result.f_score[result.current]}"
            )
            self.path_cost_label.setText(
                f"Path Cost: {result.g_score[result.current]}"
            )
            self.shortest_distance_label.setText(
                f"Shortest Distance: {result.g_score[result.current]}"
            )
            self.path_length_label.setText("Path Length: -")
            self.path_label.setText("Shortest Path: searching...")
            return
        self.frontier_label.setText("Frontier Cells: 0")
        if result.found and result.path is not None:
            self.status_label.setText("Status: Path Found")
            self.shortest_distance_label.setText(
                f"Shortest Distance: {len(result.path) - 1}"
            )
            self.path_cost_label.setText(
                f"Path Cost: {len(result.path) - 1}"
            )
            self.path_length_label.setText(
                f"Path Length: {len(result.path)} cells"
            )
            self.path_label.setText(
                "Shortest Path: "
                + " -> ".join(str(position) for position in result.path)
            )
        else:
            self.status_label.setText("Status: No Path Found")
            self.shortest_distance_label.setText("Shortest Distance: N/A")
            self.path_cost_label.setText("Path Cost: -")
            self.path_length_label.setText("Path Length: N/A")
            self.path_label.setText(
                "Shortest Path: No path exists; goal is unreachable."
            )

    def _reset_view(self):
        self.timer.stop()
        self.edit_mode = False
        self.placement_mode = None
        self.search_result = None
        self.stepper = None
        self.animation_started_at = None
        self.maze_widget.set_maze(self.maze)
        self.maze_widget.set_edit_mode(False)
        self.algorithm_label.setText("A* Search")
        self.mode_label.setText("Mode: View")
        self.update_maze_information()
        self.update_test_information()
        self.update_search_information()
        self.status_label.setText("Status: Ready")
        self.execution_label.setText("Execution Time: -")
        self.current_node_label.setText("Current Node: -")
        self.current_g_label.setText("Current g: -")
        self.current_h_label.setText("Current h: -")
        self.current_f_label.setText("Current f: -")
        self.solve_button.setEnabled(True)
        self.solve_button.setText("Start / Solve")
        self.pause_button.setEnabled(False)
        self.edit_button.setEnabled(True)
        self.clear_button.setEnabled(True)
        self.reset_button.setEnabled(True)
        self._sync_grid_size_inputs()

    def load_sample_maze(self):
        """Load the project's existing sample maze."""
        self.maze = Maze()
        self._reset_view()

    def apply_grid_size(self):
        """Create a fresh open maze using the requested row and column count."""
        if self.stepper is not None and self.search_result is None:
            self.timer.stop()

        row_count = self.rows_spinbox.value()
        column_count = self.columns_spinbox.value()
        grid = [
            [self.maze.OPEN for _ in range(column_count)]
            for _ in range(row_count)
        ]
        grid[0][0] = self.maze.START
        grid[row_count - 1][column_count - 1] = self.maze.GOAL
        self.maze = Maze(grid)
        self._reset_view()

    def _sync_grid_size_inputs(self):
        """Keep the size controls aligned with the currently loaded maze."""
        row_count = len(self.maze.grid)
        column_count = len(self.maze.grid[0]) if row_count else 0
        self.rows_spinbox.blockSignals(True)
        self.columns_spinbox.blockSignals(True)
        self.rows_spinbox.setValue(max(2, min(50, row_count or 2)))
        self.columns_spinbox.setValue(max(2, min(50, column_count or 2)))
        self.rows_spinbox.blockSignals(False)
        self.columns_spinbox.blockSignals(False)

    def toggle_edit_mode(self):
        """Toggle click-to-toggle wall editing on the actual Maze."""
        if self.stepper is not None and self.search_result is None:
            return
        self.edit_mode = not self.edit_mode
        self.placement_mode = None
        self.maze_widget.set_edit_mode(self.edit_mode)
        self.solve_button.setEnabled(not self.edit_mode)
        self.pause_button.setEnabled(False)
        self.edit_button.setText("Done Editing" if self.edit_mode else "Edit Maze")
        self.mode_label.setText(
            "Mode: Edit Maze" if self.edit_mode else "Mode: View"
        )
        self.status_label.setText(
            "Status: Edit Maze" if self.edit_mode else "Status: Ready"
        )
        self.mode_label.setText(
            "Edit Maze" if self.edit_mode else "View"
        )
        self.update_maze_information()

    def _clear_search_state(self):
        self.timer.stop()
        self.stepper = None
        self.search_result = None
        self.maze_widget.set_search_result(None)
        self._reset_search_labels()

    def _reset_search_labels(self):
        self.shortest_distance_label.setText("Shortest Distance: -")
        self.path_cost_label.setText("Path Cost: -")
        self.path_length_label.setText("Path Length: -")
        self.explored_label.setText("Explored Cells: -")
        self.frontier_label.setText("Frontier Cells: -")
        self.execution_label.setText("Execution Time: -")
        self.current_node_label.setText("Current Node: -")
        self.current_g_label.setText("Current g: -")
        self.current_h_label.setText("Current h: -")
        self.current_f_label.setText("Current f: -")

    def clear_maze(self):
        """Remove all walls while preserving the current Start and Goal."""
        for row_index, row in enumerate(self.maze.grid):
            for column_index, cell in enumerate(row):
                if cell == self.maze.WALL:
                    self.maze.grid[row_index][column_index] = self.maze.OPEN
        self._clear_search_state()
        self.status_label.setText("Status: Ready")
        self.maze_widget.update()
        self.update_maze_information()

    def _handle_cell_click(self, position):
        if not self.edit_mode:
            return
        row_index, column_index = position
        cell = self.maze.grid[row_index][column_index]
        if position in (self.maze.start, self.maze.goal):
            return
        self.maze.grid[row_index][column_index] = (
            self.maze.OPEN if cell == self.maze.WALL else self.maze.WALL
        )
        self._clear_search_state()
        self.status_label.setText("Status: Edit Maze")
        self.maze_widget.update()
        self.update_maze_information()

    def reset_maze(self):
        """Restore the sample maze and clear the current search result."""
        self.load_sample_maze()

    def set_maze_for_testing(self, maze):
        """Set a maze for smoke tests without adding a user editing feature."""
        self.maze = maze
        self._reset_view()

    def solve_maze(self):
        """Run the existing A* implementation and update the UI."""
        if not self.maze.validate():
            self.status_label.setText("Status: Invalid Maze")
            self.maze_status_label.setText("Invalid Maze")
            return
        self.status_label.setText("Status: Solving...")
        self.solve_button.setEnabled(False)
        QApplication.processEvents()
        started = time.perf_counter()
        try:
            self.search_result = astar_search(self.maze)
        except (ValueError, TypeError) as error:
            print(f"Maze solve error: {error}", file=sys.stderr)
            self.search_result = None
            self.status_label.setText("Status: Search Error")
            self.explored_label.setText("Explored Cells: -")
            self.solve_button.setEnabled(True)
            return
        except Exception as error:
            print(f"Unexpected maze solve error: {error}", file=sys.stderr)
            self.search_result = None
            self.status_label.setText("Status: Search Error")
            self.explored_label.setText("Explored Cells: -")
            self.solve_button.setEnabled(True)
            return

        elapsed_ms = (time.perf_counter() - started) * 1000
        self.maze_widget.set_search_result(self.search_result)
        self.execution_label.setText(f"Execution Time: {elapsed_ms:.3f} ms")
        self.update_search_information(self.search_result)
        self.solve_button.setEnabled(True)

    def start_or_resume(self):
        """Start a new stepper or resume the paused one."""
        if self.stepper is None:
            if self.edit_mode:
                return
            if not self.maze.validate():
                self.status_label.setText("Status: Invalid Maze")
                self.maze_status_label.setText("Invalid Maze")
                return
            try:
                self.stepper = AStarStepper(self.maze)
            except (ValueError, TypeError) as error:
                print(f"Maze animation error: {error}", file=sys.stderr)
                self.status_label.setText("Status: Search Error")
                return
            self.search_result = None
            self.maze_widget.set_search_result(None)
            self.animation_started_at = time.perf_counter()
        self.status_label.setText("Status: Solving...")
        self.solve_button.setEnabled(False)
        self.pause_button.setEnabled(True)
        self.timer.start(self.speed_slider.value())

    def pause_animation(self):
        """Pause the current stepper without discarding its state."""
        if self.stepper is not None and self.search_result is None:
            self.timer.stop()
            self.status_label.setText("Status: Paused")
            self.solve_button.setText("Resume")
            self.solve_button.setEnabled(True)
            self.pause_button.setEnabled(False)

    def _update_timer_interval(self, interval):
        if self.timer.isActive():
            self.timer.setInterval(interval)

    def _advance_animation(self):
        if self.stepper is None:
            self.timer.stop()
            return
        snapshot = self.stepper.step()
        if snapshot is not None:
            self.maze_widget.set_search_snapshot(snapshot)
            self.update_search_information(snapshot)
            if snapshot.goal_reached:
                self._finish_animation(self.stepper.result)
        elif self.stepper.result is not None:
            self._finish_animation(self.stepper.result)

    def _finish_animation(self, result):
        self.timer.stop()
        self.search_result = result
        self.maze_widget.set_search_result(result)
        elapsed_ms = (time.perf_counter() - self.animation_started_at) * 1000
        self.execution_label.setText(f"Execution Time: {elapsed_ms:.3f} ms")
        self.update_search_information(result)
        self.solve_button.setText("Start / Solve")
        self.solve_button.setEnabled(True)
        self.pause_button.setEnabled(False)


def run_application():
    """Create and run the Qt application."""
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()
