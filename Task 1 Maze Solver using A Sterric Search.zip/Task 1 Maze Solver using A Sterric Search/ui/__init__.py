"""Desktop user interface for the A* Maze Solver."""
