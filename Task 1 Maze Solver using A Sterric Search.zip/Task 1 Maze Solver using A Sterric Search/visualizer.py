"""Console visualization for completed A* search results."""


def cell_symbol(maze, position, result):
    """Return the display symbol for one position using the required priority."""
    row_index, column_index = position
    if maze.grid[row_index][column_index] == maze.WALL:
        return maze.WALL
    if position == maze.start:
        return maze.START
    if position == maze.goal:
        return maze.GOAL
    if result.path is not None and position in result.path:
        return "P"
    if position in result.closed_set:
        return "E"
    return maze.OPEN


def render_maze(maze, result):
    """Return a text visualization and statistics for an A* result."""
    lines = [
        "Maze visualization:",
        *[
            " ".join(
                cell_symbol(maze, (row_index, column_index), result)
                for column_index in range(len(row))
            )
            for row_index, row in enumerate(maze.grid)
        ],
        "",
        "Legend:",
        "# = Wall",
        ". = Unexplored open cell",
        "E = Explored/processed cell",
        "P = Shortest path",
        "S = Start",
        "G = Goal",
        "",
        f"Path Found: {result.found}",
        f"Explored Cells: {len(result.closed_set)}",
    ]
    if result.found and result.path is not None:
        lines.extend(
            [
                f"Path Cost: {len(result.path) - 1}",
                f"Path Length: {len(result.path)}",
            ]
        )
    else:
        lines.append("No path exists.")
    return "\n".join(lines)


def visualize_maze(maze, result):
    """Print the completed-search visualization without running another search."""
    visualization = render_maze(maze, result)
    print(visualization)
    return visualization
