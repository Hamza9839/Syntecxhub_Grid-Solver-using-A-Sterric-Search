"""Unit tests for the basic Maze class."""

import unittest

from maze import Maze, manhattan_distance


class TestMaze(unittest.TestCase):
    def test_valid_maze(self):
        self.assertTrue(Maze().validate())

    def test_find_start(self):
        self.assertEqual(Maze().find_start(), (0, 0))

    def test_find_goal(self):
        self.assertEqual(Maze().find_goal(), (4, 5))

    def test_invalid_maze_with_no_start(self):
        grid = Maze.sample_grid()
        grid[0][0] = "."
        self.assertFalse(Maze(grid).validate())

    def test_invalid_maze_with_multiple_starts(self):
        grid = Maze.sample_grid()
        grid[1][0] = "S"
        self.assertFalse(Maze(grid).validate())

    def test_invalid_maze_with_no_goal(self):
        grid = Maze.sample_grid()
        grid[4][5] = "."
        self.assertFalse(Maze(grid).validate())

    def test_invalid_characters(self):
        grid = Maze.sample_grid()
        grid[0][1] = "X"
        self.assertFalse(Maze(grid).validate())

    def test_unequal_row_lengths(self):
        grid = Maze.sample_grid()
        grid[1].pop()
        self.assertFalse(Maze(grid).validate())

    def test_neighbors_from_corner(self):
        self.assertEqual(Maze().get_neighbors((0, 0)), [(1, 0), (0, 1)])

    def test_neighbors_from_edge(self):
        self.assertEqual(Maze().get_neighbors((0, 2)), [(1, 2), (0, 1)])

    def test_neighbors_from_middle(self):
        self.assertEqual(
            Maze().get_neighbors((2, 2)),
            [(1, 2), (3, 2), (2, 3)],
        )

    def test_position_surrounded_by_walls(self):
        grid = [
            ["#", "#", "#"],
            ["#", ".", "#"],
            ["#", "#", "#"],
        ]
        self.assertEqual(Maze(grid).get_neighbors((1, 1)), [])

    def test_position_with_open_and_wall_neighbors(self):
        self.assertEqual(
            Maze().get_neighbors((3, 2)),
            [(2, 2), (4, 2), (3, 1)],
        )

    def test_position_next_to_boundary(self):
        self.assertEqual(Maze().get_neighbors((4, 2)), [(3, 2), (4, 3)])

    def test_diagonal_cells_are_not_neighbors(self):
        grid = [
            [".", ".", "."],
            [".", "S", "."],
            [".", ".", "G"],
        ]
        neighbors = Maze(grid).get_neighbors((1, 1))
        self.assertEqual(neighbors, [(0, 1), (2, 1), (1, 0), (1, 2)])
        self.assertNotIn((0, 0), neighbors)
        self.assertNotIn((0, 2), neighbors)
        self.assertNotIn((2, 0), neighbors)
        self.assertNotIn((2, 2), neighbors)

    def test_walls_are_not_neighbors(self):
        self.assertNotIn((2, 1), Maze().get_neighbors((2, 2)))

    def test_positions_outside_grid_are_safe(self):
        maze = Maze()
        self.assertFalse(maze.is_walkable((-1, 0)))
        self.assertFalse(maze.is_walkable((5, 0)))
        self.assertFalse(maze.is_walkable((0, 6)))
        self.assertEqual(maze.get_neighbors((-1, 0)), [])
        self.assertEqual(maze.get_neighbors((5, 0)), [])
        self.assertEqual(maze.get_neighbors((0, 6)), [])

    def test_manhattan_distance_from_origin(self):
        self.assertEqual(manhattan_distance((0, 0), (4, 5)), 9)

    def test_manhattan_distance_between_positions(self):
        self.assertEqual(manhattan_distance((1, 2), (4, 5)), 6)

    def test_manhattan_distance_is_symmetric(self):
        self.assertEqual(manhattan_distance((4, 5), (1, 2)), 6)

    def test_manhattan_distance_to_same_position(self):
        self.assertEqual(manhattan_distance((2, 2), (2, 2)), 0)

    def test_manhattan_distance_with_reverse_row_and_column_order(self):
        self.assertEqual(manhattan_distance((0, 5), (4, 0)), 9)

    def test_maze_heuristic_uses_actual_goal(self):
        maze = Maze()
        self.assertEqual(maze.heuristic((0, 0)), 9)
        self.assertEqual(maze.heuristic((1, 2)), 6)
        self.assertEqual(maze.heuristic(maze.find_goal()), 0)


if __name__ == "__main__":
    unittest.main()
