"""Basic maze/grid representation for the Maze Solver project."""


def manhattan_distance(current, goal):
    """Return the grid distance between two (row, column) positions."""
    current_row, current_column = current
    goal_row, goal_column = goal
    return abs(current_row - goal_row) + abs(current_column - goal_column)


class Maze:
    """Represent a rectangular maze made from simple text symbols."""

    START = "S"
    GOAL = "G"
    WALL = "#"
    OPEN = "."
    VALID_SYMBOLS = {START, GOAL, WALL, OPEN}

    def __init__(self, grid=None):
        """Create a maze from a 2D list, or use the built-in sample maze."""
        if grid is None:
            grid = self.sample_grid()
        self.grid = grid

    @staticmethod
    def sample_grid():
        """Return a fresh copy of the built-in sample maze."""
        return [
            ["S", ".", ".", "#", ".", "."],
            [".", "#", ".", "#", ".", "."],
            [".", "#", ".", ".", ".", "."],
            [".", ".", ".", "#", "#", "."],
            ["#", "#", ".", ".", ".", "G"],
        ]

    def display(self):
        """Print the maze with spaces between cells."""
        for row in self.grid:
            print(" ".join(row))

    def is_walkable(self, position):
        """Return whether position is inside the grid and is not a wall."""
        try:
            row_index, column_index = position
        except (TypeError, ValueError):
            return False

        if row_index < 0 or row_index >= len(self.grid):
            return False
        if column_index < 0 or column_index >= len(self.grid[row_index]):
            return False

        return self.grid[row_index][column_index] != self.WALL

    def get_neighbors(self, position):
        """Return walkable neighbors in UP, DOWN, LEFT, RIGHT order."""
        try:
            row_index, column_index = position
        except (TypeError, ValueError):
            return []

        if not self.is_walkable(position):
            return []

        possible_neighbors = [
            (row_index - 1, column_index),  # UP
            (row_index + 1, column_index),  # DOWN
            (row_index, column_index - 1),  # LEFT
            (row_index, column_index + 1),  # RIGHT
        ]
        return [
            neighbor
            for neighbor in possible_neighbors
            if self.is_walkable(neighbor)
        ]

    def find_start(self):
        """Return the (row, column) of the start, or None if it is absent."""
        return self._find_symbol(self.START)

    @property
    def start(self):
        """Return the start position."""
        return self.find_start()

    def find_goal(self):
        """Return the (row, column) of the goal, or None if it is absent."""
        return self._find_symbol(self.GOAL)

    @property
    def goal(self):
        """Return the goal position."""
        return self.find_goal()

    def heuristic(self, position):
        """Return the Manhattan distance from position to this maze's goal."""
        goal = self.find_goal()
        if goal is None:
            raise ValueError("Cannot calculate a heuristic without a goal.")
        return manhattan_distance(position, goal)

    def _find_symbol(self, symbol):
        for row_index, row in enumerate(self.grid):
            for column_index, cell in enumerate(row):
                if cell == symbol:
                    return row_index, column_index
        return None

    def validate(self):
        """Return True when the maze has a valid rectangular layout."""
        if not self.grid:
            return False

        column_count = len(self.grid[0])
        if column_count == 0:
            return False

        start_count = 0
        goal_count = 0

        for row in self.grid:
            if len(row) != column_count:
                return False

            for cell in row:
                if cell not in self.VALID_SYMBOLS:
                    return False
                if cell == self.START:
                    start_count += 1
                elif cell == self.GOAL:
                    goal_count += 1

        return start_count == 1 and goal_count == 1
