# Maze Solver using A* Search

## Step 8: Desktop UI

This step creates a beginner-friendly `Maze` class that stores a maze as a
two-dimensional Python list, identifies valid neighboring positions, and
calculates Manhattan distance estimates, runs A* search, reconstructs the
shortest path using parent tracking, reports unreachable goals normally, and
renders completed searches in the console and provides a PySide6 desktop UI.

### Symbols

- `S` - Start
- `G` - Goal
- `#` - Wall
- `.` - Open/walkable cell

### Project files

- `maze.py` - The `Maze` class, sample grid, display, position lookup, validation, neighbor detection, and Manhattan distance.
- `astar.py` - A* search using an `heapq` priority queue, a closed set, and `came_from` parent tracking.
- `visualizer.py` - Dependency-free grid visualization that consumes a Maze and SearchResult.
- `ui/maze_widget.py` - Custom QWidget that draws the maze and search state.
- `ui/main_window.py` - Main desktop window, controls, statistics, and A* integration.
- `main.py` - Launches the PySide6 desktop application.
- `test_maze.py` - Unit tests for validation, position lookup, neighbor detection, and Manhattan distance.
- `test_astar.py` - Unit tests for reachable and unreachable A* searches and score handling.
- `test_path_reconstruction.py` - Unit tests for parent tracking and path reconstruction.
- `test_unreachable.py` - Unit tests for blocked, separated, trapped, and cyclic mazes.
- `test_visualizer.py` - Unit tests for reachable, unreachable, path, explored-cell, and wall rendering.
- `test_ui.py` - Headless smoke tests for the desktop UI.

`get_neighbors(position)` checks only the four directions UP, DOWN, LEFT,
and RIGHT. It returns in-bounds positions that are not walls, in that
deterministic order. Diagonal movement is not included.

`manhattan_distance(current, goal)` uses:

```text
abs(current_row - goal_row) + abs(current_column - goal_column)
```

`Maze.heuristic(position)` applies this formula between a position and the
maze's goal. It does not inspect walls or calculate a path.

`astar_search(maze)` maintains:

- `g_score`: actual movement cost from the start, with each move costing 1.
- `f_score`: `g(n) + h(n)`.
- An `heapq`-based open set ordered by lowest f-score with a tie-breaker.
- A closed set of nodes that have already been processed.

When a node's best route improves, `came_from[neighbor] = current` records its
parent. Once the goal is reached, `reconstruct_path()` follows those links
backward and reverses the collected positions to return a path from start to
goal. An unreachable goal returns `path = None`. Since the maze format
requires separate `S` and `G` cells, a start-equals-goal maze is invalid.

If the priority queue becomes empty before the goal is processed, the search
returns `found = False` and `path = None` with the collected scores and closed
set. This is a normal result, not an exception.

The console visualizer uses `#` for walls, `.` for unexplored cells, `E` for
explored cells, `P` for the returned shortest path, `S` for Start, and `G` for
Goal. It consumes the existing `closed_set` and `path`; it never runs a second
search or modifies the maze.

The desktop UI uses the same `Maze`, `astar_search`, and `SearchResult`
objects. Solve Maze runs the existing A* implementation, while Reset and Load
Sample Maze clear the displayed result and restore the sample maze.

The desktop UI also supports Step 9 real-time search animation through
`AStarStepper` and `QTimer`. The stepper uses the same A* scoring and neighbor
logic, while pause/resume preserves the current search state.

### Run the System

```text
python main.py
```
