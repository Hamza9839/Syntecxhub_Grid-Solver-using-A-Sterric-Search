"""Unit tests for the Step 4 A* search implementation."""

import math
import unittest

from astar import astar_search
from maze import Maze, manhattan_distance


class TestAStarSearch(unittest.TestCase):
    def test_sample_maze_reaches_goal(self):
        result = astar_search(Maze())
        self.assertTrue(result.found)
        self.assertIn(Maze().goal, result.closed_set)

    def test_start_has_zero_g_score(self):
        maze = Maze()
        result = astar_search(maze)
        self.assertEqual(result.g_score[maze.start], 0)

    def test_reachable_goal_has_finite_g_score(self):
        maze = Maze()
        result = astar_search(maze)
        self.assertTrue(math.isfinite(result.g_score[maze.goal]))

    def test_processed_nodes_have_correct_f_scores(self):
        maze = Maze()
        result = astar_search(maze)
        for position in result.processed_order:
            expected = result.g_score[position] + manhattan_distance(
                position, maze.goal
            )
            self.assertEqual(result.f_score[position], expected)

    def test_closed_set_has_no_duplicate_processed_nodes(self):
        result = astar_search(Maze())
        self.assertEqual(len(result.processed_order), len(result.closed_set))
        self.assertEqual(
            len(result.processed_order),
            len(set(result.processed_order)),
        )

    def test_unreachable_goal_is_reported(self):
        maze = Maze(
            [
                ["S", "#", "."],
                ["#", "#", "#"],
                [".", ".", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertNotIn(maze.goal, result.closed_set)

    def test_start_equals_goal_limitation_is_documented_by_validation(self):
        maze = Maze(
            [
                ["S"],
            ]
        )
        self.assertFalse(maze.validate())


if __name__ == "__main__":
    unittest.main()
