"""Tests for the dependency-free maze visualizer."""

import unittest

from astar import astar_search
from maze import Maze
from visualizer import cell_symbol, render_maze, visualize_maze


class TestVisualizer(unittest.TestCase):
    def test_reachable_result_is_accepted(self):
        maze = Maze()
        result = astar_search(maze)
        rendered = render_maze(maze, result)
        self.assertIn("Path Found: True", rendered)

    def test_unreachable_result_is_accepted(self):
        maze = Maze(
            [
                ["S", "#", "G"],
            ]
        )
        result = astar_search(maze)
        rendered = render_maze(maze, result)
        self.assertIn("Path Found: False", rendered)
        self.assertIn("No path exists.", rendered)

    def test_path_cells_come_from_result_path(self):
        maze = Maze()
        result = astar_search(maze)
        for position in result.path:
            if position not in (maze.start, maze.goal):
                self.assertEqual(cell_symbol(maze, position, result), "P")

    def test_explored_cells_come_from_closed_set(self):
        maze = Maze()
        result = astar_search(maze)
        for position in result.closed_set:
            if position not in (maze.start, maze.goal) and position not in result.path:
                self.assertEqual(cell_symbol(maze, position, result), "E")

    def test_start_and_goal_remain_identifiable(self):
        maze = Maze()
        result = astar_search(maze)
        self.assertEqual(cell_symbol(maze, maze.start, result), "S")
        self.assertEqual(cell_symbol(maze, maze.goal, result), "G")

    def test_walls_are_never_rendered_as_walkable(self):
        maze = Maze()
        result = astar_search(maze)
        for row_index, row in enumerate(maze.grid):
            for column_index, cell in enumerate(row):
                if cell == maze.WALL:
                    self.assertEqual(
                        cell_symbol(maze, (row_index, column_index), result),
                        maze.WALL,
                    )

    def test_visualize_maze_prints_and_returns_rendering(self):
        maze = Maze()
        result = astar_search(maze)
        self.assertIn("Legend:", visualize_maze(maze, result))


if __name__ == "__main__":
    unittest.main()
