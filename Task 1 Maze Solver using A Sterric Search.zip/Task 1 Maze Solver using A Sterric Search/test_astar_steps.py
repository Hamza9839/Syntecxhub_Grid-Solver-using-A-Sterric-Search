"""Tests for incremental A* search progression."""

import unittest

from astar import AStarStepper, astar_search
from maze import Maze


class TestAStarStepper(unittest.TestCase):
    def test_stepper_starts_with_start_node(self):
        stepper = AStarStepper(Maze())
        snapshot = stepper.step()
        self.assertEqual(snapshot.current, (0, 0))
        self.assertIn((0, 0), snapshot.closed_set)

    def test_reachable_stepper_reaches_goal(self):
        stepper = AStarStepper(Maze())
        snapshots = []
        while stepper.result is None:
            snapshot = stepper.step()
            if snapshot is not None:
                snapshots.append(snapshot)
        self.assertTrue(stepper.result.found)
        self.assertEqual(snapshots[-1].current, Maze().goal)

    def test_unreachable_stepper_finishes_without_path(self):
        maze = Maze([["S", "#", "G"]])
        stepper = AStarStepper(maze)
        while stepper.result is None:
            stepper.step()
        self.assertFalse(stepper.result.found)
        self.assertIsNone(stepper.result.path)

    def test_existing_search_api_remains_correct(self):
        result = astar_search(Maze())
        self.assertTrue(result.found)
        self.assertEqual(result.g_score[Maze().goal], 9)

    def test_step_exposes_current_and_frontier(self):
        step = AStarStepper(Maze()).step()
        self.assertEqual(step.current, (0, 0))
        self.assertIsInstance(step.frontier, set)
        self.assertTrue(step.frontier)


if __name__ == "__main__":
    unittest.main()
