"""A* search for the maze and shortest-path reconstruction."""

from dataclasses import dataclass
import heapq
from itertools import count

from maze import manhattan_distance


@dataclass
class SearchResult:
    """Information collected while running A* search."""

    found: bool
    path: list
    g_score: dict
    f_score: dict
    closed_set: set
    processed_order: list
    came_from: dict

    @property
    def processed_nodes(self):
        """Return the number of nodes removed from the open set and processed."""
        return len(self.processed_order)


@dataclass
class AStarStep:
    """Snapshot emitted after one real A* node-processing step."""

    current: tuple
    closed_set: set
    open_set: set
    g_score: dict
    f_score: dict
    h_score: int
    goal_reached: bool
    result: object = None

    @property
    def frontier(self):
        """Return the current open-set frontier."""
        return self.open_set


class AStarStepper:
    """Incremental A* search state used by responsive UI animations."""

    def __init__(self, maze):
        if not maze.validate():
            raise ValueError("Cannot search an invalid maze.")
        self.maze = maze
        self.start = maze.start
        self.goal = maze.goal
        if self.start is None or self.goal is None:
            raise ValueError("Maze must have both a start and a goal.")

        self.open_set = []
        self._tie_breaker = count()
        self.g_score = {self.start: 0}
        self.f_score = {self.start: manhattan_distance(self.start, self.goal)}
        heapq.heappush(
            self.open_set,
            (self.f_score[self.start], next(self._tie_breaker), self.start),
        )
        self.closed_set = set()
        self.processed_order = []
        self.came_from = {}
        self.result = None

    def _snapshot(self, current, goal_reached):
        return AStarStep(
            current=current,
            closed_set=set(self.closed_set),
            open_set={entry[2] for entry in self.open_set},
            g_score=dict(self.g_score),
            f_score=dict(self.f_score),
            h_score=manhattan_distance(current, self.goal),
            goal_reached=goal_reached,
            result=self.result,
        )

    def step(self):
        """Process one node, returning a snapshot or None when finished."""
        if self.result is not None:
            return None

        while self.open_set:
            _, _, current = heapq.heappop(self.open_set)
            if current in self.closed_set:
                continue

            self.closed_set.add(current)
            self.processed_order.append(current)
            if current == self.goal:
                self.result = SearchResult(
                    True,
                    reconstruct_path(
                        self.came_from, self.start, self.goal
                    ),
                    self.g_score,
                    self.f_score,
                    self.closed_set,
                    self.processed_order,
                    self.came_from,
                )
                return self._snapshot(current, True)

            current_g = self.g_score[current]
            for neighbor in self.maze.get_neighbors(current):
                if neighbor in self.closed_set:
                    continue
                tentative_g = current_g + 1
                if tentative_g < self.g_score.get(neighbor, float("inf")):
                    self.g_score[neighbor] = tentative_g
                    self.came_from[neighbor] = current
                    self.f_score[neighbor] = tentative_g + manhattan_distance(
                        neighbor, self.goal
                    )
                    heapq.heappush(
                        self.open_set,
                        (
                            self.f_score[neighbor],
                            next(self._tie_breaker),
                            neighbor,
                        ),
                    )
            return self._snapshot(current, False)

        self.result = SearchResult(
            False,
            None,
            self.g_score,
            self.f_score,
            self.closed_set,
            self.processed_order,
            self.came_from,
        )
        return None


def reconstruct_path(came_from, start, goal):
    """Follow parent links from goal to start and return the ordered path."""
    path = [goal]
    current = goal

    while current != start:
        if current not in came_from:
            return None
        current = came_from[current]
        path.append(current)

    path.reverse()
    return path


def astar_search(maze):
    """Run A* search and return scores, parents, and the shortest path."""
    if not maze.validate():
        raise ValueError("Cannot search an invalid maze.")

    start = maze.start
    goal = maze.goal
    if start is None or goal is None:
        raise ValueError("Maze must have both a start and a goal.")

    open_set = []
    tie_breaker = count()
    g_score = {start: 0}
    f_score = {start: manhattan_distance(start, goal)}
    heapq.heappush(open_set, (f_score[start], next(tie_breaker), start))

    closed_set = set()
    processed_order = []
    came_from = {}

    while open_set:
        _, _, current = heapq.heappop(open_set)

        if current in closed_set:
            continue

        closed_set.add(current)
        processed_order.append(current)

        if current == goal:
            return SearchResult(
                True,
                reconstruct_path(came_from, start, goal),
                g_score,
                f_score,
                closed_set,
                processed_order,
                came_from,
            )

        current_g = g_score[current]
        for neighbor in maze.get_neighbors(current):
            if neighbor in closed_set:
                continue

            tentative_g = current_g + 1
            if tentative_g < g_score.get(neighbor, float("inf")):
                g_score[neighbor] = tentative_g
                came_from[neighbor] = current
                f_score[neighbor] = tentative_g + manhattan_distance(
                    neighbor, goal
                )
                heapq.heappush(
                    open_set,
                    (f_score[neighbor], next(tie_breaker), neighbor),
                )

    return SearchResult(
        False, None, g_score, f_score, closed_set, processed_order, came_from
    )
