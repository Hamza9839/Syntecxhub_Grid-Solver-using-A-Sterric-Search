"""Tests for normal handling of unreachable maze goals."""

import unittest

from astar import astar_search
from maze import Maze


class TestUnreachableCases(unittest.TestCase):
    def test_completely_blocked_goal(self):
        maze = Maze(
            [
                ["S", ".", "."],
                [".", "#", "#"],
                [".", "#", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertIsNone(result.path)

    def test_start_region_separated_from_goal(self):
        maze = Maze(
            [
                ["S", ".", "#", ".", "."],
                [".", ".", "#", ".", "."],
                ["#", "#", "#", "#", "#"],
                [".", ".", ".", ".", "."],
                [".", ".", ".", ".", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertIsNone(result.path)

    def test_start_is_trapped(self):
        maze = Maze(
            [
                ["#", "#", "#"],
                ["#", "S", "#"],
                ["#", "#", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertIsNone(result.path)
        self.assertEqual(result.processed_nodes, 1)

    def test_goal_is_trapped(self):
        maze = Maze(
            [
                ["S", ".", "."],
                [".", ".", "."],
                [".", ".", "G"],
            ]
        )
        maze.grid[1][2] = "#"
        maze.grid[2][1] = "#"
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertIsNone(result.path)

    def test_narrow_route_is_blocked_in_middle(self):
        maze = Maze(
            [
                ["S", ".", ".", "#", "G"],
                ["#", "#", ".", "#", "#"],
                [".", ".", ".", ".", "."],
            ]
        )
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertIsNone(result.path)
        self.assertGreater(result.processed_nodes, 1)

    def test_reachable_maze_still_finds_path(self):
        result = astar_search(Maze())
        self.assertTrue(result.found)
        self.assertIsNotNone(result.path)

    def test_cycles_terminate_without_duplicate_processing(self):
        maze = Maze(
            [
                ["S", ".", ".", "."],
                [".", "#", ".", "."],
                [".", ".", ".", "#"],
                ["#", ".", ".", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertTrue(result.found)
        self.assertEqual(
            len(result.processed_order),
            len(set(result.processed_order)),
        )


if __name__ == "__main__":
    unittest.main()
