"""Unit tests for Step 5 path reconstruction."""

import unittest

from astar import astar_search, reconstruct_path
from maze import Maze, manhattan_distance


class TestPathReconstruction(unittest.TestCase):
    def test_sample_path_starts_and_ends_correctly(self):
        maze = Maze()
        result = astar_search(maze)
        self.assertIsNotNone(result.path)
        self.assertEqual(result.path[0], maze.start)
        self.assertEqual(result.path[-1], maze.goal)

    def test_path_nodes_are_consecutive_neighbors(self):
        maze = Maze()
        result = astar_search(maze)
        for current, next_node in zip(result.path, result.path[1:]):
            self.assertIn(next_node, maze.get_neighbors(current))

    def test_path_contains_no_walls(self):
        maze = Maze()
        result = astar_search(maze)
        for row, column in result.path:
            self.assertNotEqual(maze.grid[row][column], maze.WALL)

    def test_path_has_no_diagonal_moves(self):
        maze = Maze()
        result = astar_search(maze)
        for current, next_node in zip(result.path, result.path[1:]):
            self.assertEqual(manhattan_distance(current, next_node), 1)

    def test_path_cost_matches_goal_g_score(self):
        maze = Maze()
        result = astar_search(maze)
        self.assertEqual(len(result.path) - 1, result.g_score[maze.goal])

    def test_parent_tracking_matches_sample_path(self):
        maze = Maze(
            [
                ["S", ".", "."],
                ["#", "#", "."],
                [".", ".", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertEqual(result.path, [(0, 0), (0, 1), (0, 2), (1, 2), (2, 2)])
        for parent, child in zip(result.path, result.path[1:]):
            self.assertEqual(result.came_from[child], parent)

    def test_reconstructed_path_follows_explicit_parent_links(self):
        came_from = {(0, 1): (0, 0), (1, 1): (0, 1)}
        self.assertEqual(
            reconstruct_path(came_from, (0, 0), (1, 1)),
            [(0, 0), (0, 1), (1, 1)],
        )

    def test_shortest_path_cost(self):
        maze = Maze(
            [
                ["S", ".", ".", "."],
                [".", "#", "#", "."],
                [".", ".", ".", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertEqual(result.g_score[maze.goal], 5)
        self.assertEqual(len(result.path) - 1, 5)

    def test_unreachable_maze_has_no_path(self):
        maze = Maze(
            [
                ["S", "#", "."],
                ["#", "#", "#"],
                [".", ".", "G"],
            ]
        )
        result = astar_search(maze)
        self.assertFalse(result.found)
        self.assertIsNone(result.path)


if __name__ == "__main__":
    unittest.main()
