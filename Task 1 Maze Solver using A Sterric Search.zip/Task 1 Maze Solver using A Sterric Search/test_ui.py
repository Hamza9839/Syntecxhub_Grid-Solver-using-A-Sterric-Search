"""Headless smoke tests for the Step 8 desktop UI."""

import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from maze import Maze
from ui.main_window import MainWindow


class TestMainWindow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.application = QApplication.instance() or QApplication([])

    def setUp(self):
        self.window = MainWindow()

    def tearDown(self):
        self.window.close()
        self.window.deleteLater()

    def test_initial_state_displays_sample_maze(self):
        self.assertEqual(self.window.status_label.text(), "Status: Ready")
        self.assertEqual(self.window.start_label.text(), "Start: (0, 0)")
        self.assertEqual(self.window.goal_label.text(), "Goal: (4, 5)")
        self.assertEqual(self.window.path_cost_label.text(), "Path Cost: -")

    def test_solve_updates_path_and_statistics(self):
        self.window.solve_maze()
        result = self.window.search_result
        self.assertTrue(result.found)
        self.assertEqual(self.window.status_label.text(), "Status: Path Found")
        self.assertEqual(
            self.window.path_cost_label.text(),
            f"Path Cost: {len(result.path) - 1}",
        )
        self.assertIn("ms", self.window.execution_label.text())

    def test_reset_clears_search_result(self):
        self.window.solve_maze()
        self.window.reset_maze()
        self.assertIsNone(self.window.search_result)
        self.assertEqual(self.window.status_label.text(), "Status: Ready")
        self.assertEqual(self.window.explored_label.text(), "Explored Cells: -")

    def test_unreachable_maze_shows_no_path(self):
        maze = Maze(
            [
                ["S", ".", "#", ".", "."],
                [".", ".", "#", ".", "."],
                ["#", "#", "#", "#", "#"],
                [".", ".", ".", ".", "."],
                [".", ".", ".", ".", "G"],
            ]
        )
        self.window.set_maze_for_testing(maze)
        self.window.solve_maze()
        self.assertFalse(self.window.search_result.found)
        self.assertEqual(
            self.window.status_label.text(),
            "Status: No Path Found",
        )
        self.assertEqual(self.window.path_cost_label.text(), "Path Cost: -")

    def test_pause_and_resume_preserve_stepper(self):
        self.window.start_or_resume()
        self.window._advance_animation()
        stepper = self.window.stepper
        processed = set(stepper.closed_set)
        self.window.pause_animation()
        self.assertEqual(self.window.status_label.text(), "Status: Paused")
        self.assertFalse(self.window.timer.isActive())
        self.window.start_or_resume()
        self.assertIs(self.window.stepper, stepper)
        self.assertEqual(stepper.closed_set, processed)
        self.window.timer.stop()

    def test_reset_stops_animation(self):
        self.window.start_or_resume()
        self.assertTrue(self.window.timer.isActive())
        self.window.reset_maze()
        self.assertFalse(self.window.timer.isActive())
        self.assertIsNone(self.window.stepper)

    def test_speed_control_updates_timer_interval(self):
        self.window.start_or_resume()
        self.window.speed_slider.setValue(700)
        self.assertEqual(self.window.timer.interval(), 700)
        self.window.reset_maze()

    def test_edit_mode_toggles_actual_maze_walls(self):
        self.window.toggle_edit_mode()
        self.window._handle_cell_click((0, 1))
        self.assertEqual(self.window.maze.grid[0][1], "#")
        self.window._handle_cell_click((0, 1))
        self.assertEqual(self.window.maze.grid[0][1], ".")

    def test_edit_mode_protects_start_and_goal(self):
        self.window.toggle_edit_mode()
        self.window._handle_cell_click(self.window.maze.start)
        self.window._handle_cell_click(self.window.maze.goal)
        self.assertEqual(self.window.maze.grid[0][0], "S")
        self.assertEqual(self.window.maze.grid[4][5], "G")

    def test_clear_maze_preserves_start_and_goal(self):
        self.window.toggle_edit_mode()
        self.window._handle_cell_click((0, 1))
        self.window.clear_maze()
        self.assertEqual(self.window.maze.start, (0, 0))
        self.assertEqual(self.window.maze.goal, (4, 5))
        self.assertEqual(self.window.maze.grid[0][1], ".")

    def test_custom_maze_is_solved(self):
        maze = Maze(
            [
                ["S", ".", "."],
                ["#", "#", "."],
                [".", ".", "G"],
            ]
        )
        self.window.set_maze_for_testing(maze)
        self.window.start_or_resume()
        while self.window.search_result is None:
            self.window._advance_animation()
        self.assertTrue(self.window.search_result.found)
        self.assertIs(self.window.maze, maze)

    def test_maze_information_for_sample(self):
        self.assertEqual(self.window.grid_size_label.text(), "5 x 6")
        self.assertEqual(self.window.total_cells_label.text(), "30")
        self.assertEqual(self.window.wall_cells_label.text(), "8")
        self.assertEqual(self.window.open_cells_label.text(), "22")
        self.assertEqual(self.window.start_label.text(), "Start: (0, 0)")
        self.assertEqual(self.window.goal_label.text(), "Goal: (4, 5)")

    def test_test_status_is_visible_in_sidebar(self):
        self.assertEqual(self.window.test_status_label.text(), "All Passed")
        self.assertEqual(
            self.window.tests_passed_label.text(),
            f"{self.window.LAST_VERIFIED_TEST_COUNT} passed",
        )
        self.assertEqual(self.window.test_command_label.text(), "pytest -q")

    def test_sidebar_sections_are_visible(self):
        self.window.show()
        self.application.processEvents()
        self.assertTrue(self.window.maze_status_label.isVisible())
        self.assertTrue(self.window.grid_size_label.isVisible())
        self.assertTrue(self.window.test_status_label.isVisible())

    def test_result_information_uses_search_result(self):
        self.window.solve_maze()
        result = self.window.search_result
        self.assertEqual(
            self.window.path_cost_label.text(),
            f"Path Cost: {len(result.path) - 1}",
        )
        self.assertEqual(
            self.window.path_length_label.text(),
            f"Path Length: {len(result.path)} cells",
        )
        self.assertEqual(
            self.window.explored_label.text(),
            f"Explored Cells: {len(result.closed_set)}",
        )
        self.assertIn("(0, 0)", self.window.path_label.text())
        self.assertIn("(4, 5)", self.window.path_label.text())

    def test_unreachable_result_uses_na_values(self):
        self.window.set_maze_for_testing(Maze([["S", "#", "G"]]))
        self.window.solve_maze()
        self.assertEqual(
            self.window.shortest_distance_label.text(),
            "Shortest Distance: N/A",
        )
        self.assertEqual(
            self.window.path_length_label.text(),
            "Path Length: N/A",
        )
        self.assertIn("unreachable", self.window.path_label.text())

    def test_maze_information_updates_after_wall_edit(self):
        original_walls = self.window.wall_cells_label.text()
        self.window.toggle_edit_mode()
        self.window._handle_cell_click((0, 1))
        self.assertEqual(
            self.window.wall_cells_label.text(),
            str(int(original_walls) + 1),
        )
        self.window._handle_cell_click((0, 1))
        self.assertEqual(
            self.window.wall_cells_label.text(),
            original_walls,
        )

    def test_grid_size_can_be_changed(self):
        self.window.rows_spinbox.setValue(10)
        self.window.columns_spinbox.setValue(9)
        self.window.apply_size_button.click()

        self.assertEqual(len(self.window.maze.grid), 10)
        self.assertEqual(len(self.window.maze.grid[0]), 9)
        self.assertEqual(self.window.maze.start, (0, 0))
        self.assertEqual(self.window.maze.goal, (9, 8))
        self.assertEqual(self.window.grid_size_label.text(), "10 x 9")
        self.assertEqual(self.window.total_cells_label.text(), "90")
        self.assertTrue(self.window.maze.validate())
        self.assertIsNone(self.window.search_result)

    def test_loading_sample_maze_resets_grid_size_controls(self):
        self.window.rows_spinbox.setValue(10)
        self.window.columns_spinbox.setValue(10)
        self.window.apply_grid_size()
        self.window.load_sample_maze()

        self.assertEqual(self.window.rows_spinbox.value(), 5)
        self.assertEqual(self.window.columns_spinbox.value(), 6)
        self.assertEqual(self.window.grid_size_label.text(), "5 x 6")


if __name__ == "__main__":
    unittest.main()
